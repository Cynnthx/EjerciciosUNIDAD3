import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';

interface Estudiante {
  nombre: string;
  nota: number;
  estado: string;
}

@Component({
  selector: 'app-ejercicio1',
  standalone: true,
  imports: [MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, FormsModule],
  templateUrl: './ejercicio1.component.html',
  styleUrls: ['./ejercicio1.component.css']  // corregido: styleUrls en plural
})

export class Ejercicio1Component {
  columnasMostradas: string[] = ['nombre', 'nota', 'estado'];

  // Lista de estudiantes con cálculo dinámico de estado
  estudiantes: Estudiante[] = [
    { nombre: 'Juan', nota: 8.5, estado: this.calcularEstado(8.5) },
    { nombre: 'Ian', nota: 4.5, estado: this.calcularEstado(4.5) },
    { nombre: 'Cristina', nota: 7.0, estado: this.calcularEstado(7.0) },
    { nombre: 'Maria', nota: 3.0, estado: this.calcularEstado(3.0) }
  ];

  filtroNombre: string = '';
  filtroEstado: string = '';

  // Filtrado de estudiantes basado en el nombre y el estado
  get estudiantesFiltrados(): Estudiante[] {
    return this.estudiantes.filter(estudiante =>
      (this.filtroNombre ? estudiante.nombre.toLowerCase().includes(this.filtroNombre.toLowerCase()) : true) &&
      (this.filtroEstado ? estudiante.estado === this.filtroEstado : true)
    );
  }

  // Calcular estado en base a la nota
  calcularEstado(nota: number): string {
    return nota >= 5 ? 'Aprobado' : 'Suspenso';
  }

  // Agregar un nuevo estudiante
  agregarEstudiante(): void {
    const nuevoEstudiante: Estudiante = { nombre: 'Nuevo Estudiante', nota: 0, estado: this.calcularEstado(0) };
    this.estudiantes.push(nuevoEstudiante);
  }
}
