import { Component, ViewChild } from '@angular/core';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ConfirmDialog } from './confirmDialog.component';

interface Contacto {
  nombre: string;
  telefono: string;
  email: string;
}

@Component({
  selector: 'app-ejercicio6',
  standalone: true,
  imports: [
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatDialogModule,
    MatPaginatorModule,
    CommonModule,
    ReactiveFormsModule,
    ConfirmDialog
  ],
  templateUrl: './ejercicio6.component.html',
  styleUrls: ['./ejercicio6.component.css']
})
export class Ejercicio6Component {
  contactos: Contacto[] = [];
  displayedColumns: string[] = ['nombre', 'telefono', 'email', 'acciones'];
  dataSource = new MatTableDataSource<Contacto>(this.contactos);
  contactoForm: FormGroup;
  editIndex: number | null = null;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private fb: FormBuilder, public dialog: MatDialog) {
    this.contactoForm = this.fb.group({
      nombre: ['', Validators.required],
      telefono: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  agregarContacto() {
    if (this.contactoForm.valid) {
      if (this.editIndex !== null) {
        this.contactos[this.editIndex] = this.contactoForm.value;
        this.editIndex = null;
      } else {
        this.contactos.push(this.contactoForm.value);
      }
      this.dataSource.data = this.contactos;
      this.contactoForm.reset();
    }
  }

  editarContacto(index: number) {
    this.editIndex = index;
    this.contactoForm.setValue(this.contactos[index]);
  }

  eliminarContacto(index: number) {
    const dialogRef = this.dialog.open(ConfirmDialog);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.contactos.splice(index, 1);
        this.dataSource.data = this.contactos;
      }
    });
  }
}
