import { Component, Pipe, PipeTransform } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';

interface Producto {
  nombre: string;
  precio: number;
  cantidad: number;
  total: number;
}

@Pipe({
  name: 'euroCurrency',
  standalone: true
})
export class EuroCurrencyPipe implements PipeTransform {
  transform(value: number): string {
    return `${value.toFixed(2)}€`;
  }
}

@Component({
  selector: 'app-ejercicio4',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    CommonModule,
    ReactiveFormsModule,
    EuroCurrencyPipe
  ],
  templateUrl: './ejercicio4.component.html',
  styleUrls: ['./ejercicio4.component.css']
})
export class Ejercicio4Component {
  productoForm: FormGroup;
  productos: Producto[] = [];
  totalCompra: number = 0;

  constructor(private fb: FormBuilder) {
    this.productoForm = this.fb.group({
      nombre: ['', Validators.required],
      precio: [0, [Validators.required, Validators.min(0.01)]],
      cantidad: [1, [Validators.required, Validators.min(1)]]
    });
  }

  agregarProducto() {
    if (this.productoForm.valid) {
      const { nombre, precio, cantidad } = this.productoForm.value;
      const total = precio * cantidad;

      const nuevoProducto: Producto = { nombre, precio, cantidad, total };
      this.productos.push(nuevoProducto);

      // Actualizar el total de la compra
      this.totalCompra += total;

      // Limpiar el formulario
      this.reiniciarFormulario();
    }
  }

  eliminarProducto(index: number) {
    const productoEliminado = this.productos.splice(index, 1)[0];
    if (productoEliminado) {
      this.totalCompra -= productoEliminado.total;
    }
  }

  reiniciarFormulario() {
    this.productoForm.reset({ nombre: '', precio: 0, cantidad: 1 });

  }
}
