import { Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatRadioModule } from '@angular/material/radio';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-ejercicio5',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatRadioModule,
    MatButtonModule,
    MatCardModule,
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './ejercicio5.component.html',
  styleUrls: ['./ejercicio5.component.css']
})
export class Ejercicio5Component {
  encuestaForm: FormGroup;
  respuestas: any = {};
  mostrarResumen: boolean = false;

  constructor(private fb: FormBuilder) {
    this.encuestaForm = this.fb.group({
      pregunta1: [''],
      pregunta2: [''],
      pregunta3: ['']
    });
  }

  enviarRespuestas() {
    this.respuestas = this.encuestaForm.value;
    this.mostrarResumen = true;
  }

  resetEncuesta() {
    this.encuestaForm.reset();
    this.mostrarResumen = false;
  }
}
