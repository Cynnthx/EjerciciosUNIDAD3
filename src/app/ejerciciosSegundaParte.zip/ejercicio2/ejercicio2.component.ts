import { Component } from '@angular/core';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { DialogoImagenComponent } from './dialogo-imagen.component';
import {CommonModule} from '@angular/common';

interface Imagen {
  url: string;
  descripcion: string;
}

@Component({
  selector: 'app-ejercicio2',
  standalone: true,
  imports: [
    CommonModule,
    MatGridListModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    DialogoImagenComponent],
  templateUrl: './ejercicio2.component.html',
  styleUrls: ['./ejercicio2.component.css']
})
export class Ejercicio2Component {
  imagenes: Imagen[] = [
    // {url: 'https://img.bekiaviajes.com/ciudades/portada/0000/6-h.jpg', descripcion: 'Roma'},
    // {
    //   url: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/17/90/45/f3/a-noruega-fica-no-norte.jpg?w=900&h=-1&s=1',
    //   descripcion: 'Noruega'
    // },
    // {
    //   url: 'https://viajes.nationalgeographic.com.es/medio/2019/03/20/el-cairo-egipto_6c8f0658_800x800.jpg',
    //   descripcion: 'Egipto'
    // }
  ];
  filtroDescripcion: string = '';
  nuevaImagen: Imagen = {url: '', descripcion: ''};


  constructor(public dialog: MatDialog) {
  }

  ngOnInit(): void {
    const storedImages = localStorage.getItem('imagenes');
    if (storedImages) {
      this.imagenes = JSON.parse(storedImages);
    } else {
      this.imagenes = [
        { url: 'https://img.bekiaviajes.com/ciudades/portada/0000/6-h.jpg', descripcion: 'Roma' },
        { url: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/17/90/45/f3/a-noruega-fica-no-norte.jpg?w=900&h=-1&s=1', descripcion: 'Noruega' },
        { url: 'https://viajes.nationalgeographic.com.es/medio/2019/03/20/el-cairo-egipto_6c8f0658_800x800.jpg', descripcion: 'Egipto' }
      ];
    }
  }


  get imagenesFiltradas(): Imagen[] {
    return this.imagenes.filter(imagen =>
      this.filtroDescripcion ? imagen.descripcion.toLowerCase().includes(this.filtroDescripcion.toLowerCase()) : true
    );
  }

  abrirDialogo(imagen: Imagen): void {
    this.dialog.open(DialogoImagenComponent, {
      data: imagen
    });
  }

  agregarImagen(): void {
    if (this.nuevaImagen.url && this.nuevaImagen.descripcion) {
      this.imagenes.push({...this.nuevaImagen});
      localStorage.setItem('imagenes', JSON.stringify(this.imagenes));
      this.nuevaImagen = {url: '', descripcion: ''};
    }
  }
}
