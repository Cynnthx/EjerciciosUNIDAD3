import { Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { DragDropModule, CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Tarea {
  nombre: string;
}

@Component({
  selector: 'app-ejercicio3',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    DragDropModule
  ],
  templateUrl: './ejercicio3.component.html',
  styleUrls: ['./ejercicio3.component.css']
})
export class Ejercicio3Component {
  nuevaTarea: string = '';
  pendientes: Tarea[] = [];
  enProgreso: Tarea[] = [];
  completadas: Tarea[] = [];

  agregarTarea() {
    if (this.nuevaTarea.trim()) {
      this.pendientes.push({ nombre: this.nuevaTarea.trim() });
      this.nuevaTarea = '';
    }
  }

  drop(event: CdkDragDrop<Tarea[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
  }

  moverATareaEnProgreso(tarea: Tarea) {
    this.transferirTarea(this.pendientes, this.enProgreso, tarea);
  }

  moverATareaCompletada(tarea: Tarea) {
    this.transferirTarea(this.enProgreso, this.completadas, tarea);
  }

  transferirTarea(origen: Tarea[], destino: Tarea[], tarea: Tarea) {
    const index = origen.indexOf(tarea);
    if (index > -1) {
      origen.splice(index, 1);
      destino.push(tarea);
    }
  }

  eliminarTarea(tarea: Tarea, lista: Tarea[]) {
    const index = lista.indexOf(tarea);
    if (index > -1) {
      lista.splice(index, 1);
    }
  }
}
